package com.cg.lab5.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.lab5.dto.BillDTO;
import com.cg.lab5.dto.Consumer;
import com.cg.lab5.exceptions.BillExceptions;
import com.cg.lab5.util.JNDIUtil;


public class EBillDAOImpl implements EBillDAO {

	JNDIUtil util;
	public EBillDAOImpl() throws BillExceptions {
		util=new JNDIUtil();
	}

	@Override
	public int insertBill(BillDTO bill) throws BillExceptions {

		Connection con=null;
		PreparedStatement pst=null;
		int id=getBillNo();
		try {
			con=util.getConnection();
			String insert="insert into billdetails values(?,?,?,?,?,sysdate)";
			pst=con.prepareStatement(insert);
			pst.setInt(1, id);
			pst.setInt(2, bill.getConsumerNo());
			pst.setDouble(3, bill.getCurrReading());
			pst.setDouble(4, bill.getUnitConsumed());
			pst.setDouble(5, bill.getNetAmount());
			
			int c=pst.executeUpdate();
			if(c>0){
				return id;
			}
			
			
		} catch (SQLException e) {

			throw new BillExceptions("Connection failed",e);
		}finally{
			try {
				if(pst!=null){
					pst.close();
					}
					if(con!=null){
					con.close();
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	
		return 0;
	}
	
	public int getBillNo(){
		Connection con=null;
		PreparedStatement pst=null;
		int id=0;
		String seq="select seq_bill_num.NEXTVAL from dual";
			try {
				con=util.getConnection();
				pst=con.prepareStatement(seq);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					id=rs.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			finally{
				try {
					if(pst!=null){
						pst.close();
						}
						if(con!=null){
						con.close();
						}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			}
			return id;
			
	}
	public boolean validateConsumerNo(int consumerNo) throws BillExceptions{
		Connection con=null;
		PreparedStatement pst=null;
		
		String seq="select consumer_num from consumers";
			try {
				con=util.getConnection();
				pst=con.prepareStatement(seq);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					if(consumerNo==rs.getInt(1)){
						return true;
					}
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new BillExceptions("invalid consumer numbner",e);
			}
			finally{
				try {
					if(pst!=null){
						pst.close();
						}
						if(con!=null){
						con.close();
						}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			}
		return false;
		
	}
	
	public String getConsumerName(int cno){
		Connection con=null;
		PreparedStatement pst=null;
		String cname=null;
		String seq="select consumer_name from consumers where consumer_num=?";
			try {
				con=util.getConnection();
				pst=con.prepareStatement(seq);
				pst.setInt(1, cno);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					cname=rs.getString(1);
					}
					
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}finally{
				try {
					if(pst!=null){
					pst.close();
					}
					if(con!=null){
					con.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			}
		
		return cname;
		
	}

	@Override
	public List<BillDTO> showAllConsumers(int consNo) throws BillExceptions {
		Connection con=null;
		PreparedStatement pst=null;
		String cname=null;
		String dispCons="select bill_num,consumer_num,cur_reading, unitconsumed,netamount,to_char(bill_date,'MONTH') from billdetails where consumer_num=?";
		try {
			con=util.getConnection();
			pst=con.prepareStatement(dispCons);
			pst.setInt(1, consNo);
			ResultSet rs=pst.executeQuery();
			List<BillDTO> billList=new ArrayList<BillDTO>();
			while(rs.next()){
				BillDTO bill=new BillDTO();
				bill.setBillNo(rs.getInt("bill_num"));
				bill.setConsumerNo(rs.getInt("consumer_num"));
				bill.setCurrReading(rs.getDouble("cur_reading"));
				bill.setUnitConsumed(rs.getDouble("unitconsumed"));
				bill.setNetAmount(rs.getDouble("netamount"));
				bill.setBillDate(rs.getString(6));
				
				billList.add(bill);
				
			}
			return billList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!=null){
				pst.close();
				}
				if(con!=null){
				con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
		return null;
	}
	@Override
	public Consumer showOneConsumer(int consNo) throws BillExceptions {
		Connection con=null;
		PreparedStatement pst=null;
		String cname=null;
		String dispCons="select Consumer_num,consumer_name,address from consumers where consumer_num=?";
		try {
			con=util.getConnection();
			pst=con.prepareStatement(dispCons);
			pst.setInt(1, consNo);
			ResultSet rs=pst.executeQuery();
			List<Consumer> list=new ArrayList<Consumer>();
			while(rs.next()){
				Consumer consumer=new Consumer();
				consumer.setConsumer_no(rs.getInt("Consumer_num"));
				consumer.setConsumer_name(rs.getString("consumer_name"));
				consumer.setAddress(rs.getString("address"));
				return consumer;
			}
		
		} catch (SQLException e) {
			throw new BillExceptions("SQL Error..",e);
		}
		finally{
			try {
				if(pst!=null){
				pst.close();
				}
				if(con!=null){
				con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
		return null;
		
	}

	@Override
	public List<Consumer> showAll() throws BillExceptions {
		Connection con=null;
		PreparedStatement pst=null;
		String cname=null;
		String dispCons="select Consumer_num,consumer_name,address from consumers";
		try {
			con=util.getConnection();
			pst=con.prepareStatement(dispCons);
			List<Consumer> consList=new ArrayList<Consumer>();
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				Consumer consumer=new Consumer();
				consumer.setConsumer_no(rs.getInt("Consumer_num"));
				consumer.setConsumer_name(rs.getString("consumer_name"));
				consumer.setAddress(rs.getString("address"));
				consList.add(consumer);
			}
			return consList;
		} catch (SQLException e) {
			throw new BillExceptions("SQL Error..",e);
		}
		finally{
			try {
				if(pst!=null){
				pst.close();
				}
				if(con!=null){
				con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
		
	}

	
}
