package com.cg.lab5.dao;

import java.util.List;

import com.cg.lab5.dto.BillDTO;
import com.cg.lab5.dto.Consumer;
import com.cg.lab5.exceptions.BillExceptions;

public interface EBillDAO {
	public int insertBill(BillDTO bill) throws BillExceptions;
	public boolean validateConsumerNo(int consumerNo) throws BillExceptions;
	public String getConsumerName(int cno);
	public List<Consumer> showAll()throws BillExceptions;
	Consumer showOneConsumer(int consNo) throws BillExceptions;
	List<BillDTO> showAllConsumers(int consNo) throws BillExceptions;
}
