package com.cg.lab5.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.lab5.dto.BillDTO;
import com.cg.lab5.dto.Consumer;
import com.cg.lab5.exceptions.BillExceptions;
import com.cg.lab5.service.EBillService;



@WebServlet("*.do")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EBillService services;
	ServletContext ctx=null;
	private int consumerNo;
	public void init() throws ServletException {
		ctx=super.getServletContext();
		services=(EBillService) ctx.getAttribute("services");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String nextJsp="errors.jsp";
		String path=request.getServletPath();
		RequestDispatcher dispatch=null;
		String message=null;
		switch(path) {
		case "/login.do":
			
				ctx.log("AUTHENTICATED");
				String uname=request.getParameter("uname");
				String upass=request.getParameter("upass");
				if(uname.equals("Rima") && upass.equals("123")){
					response.sendRedirect("userInfo.html");
					 HttpSession session=request.getSession(true);
					session.setAttribute("username", uname);
				}
				else{
					response.sendRedirect("login.html");
				}
				break;
		case "/calculate.do":
			
			
				consumerNo=Integer.parseInt(request.getParameter("cno"));
				double lastRead=Double.parseDouble(request.getParameter("lread"));
				double curRead=Double.parseDouble(request.getParameter("cread"));
				if(lastRead>=curRead){
					message="Last Meter reading must be less than current";
					request.setAttribute("errorMsg", message);
					response.sendRedirect("errors.jsp");
				}
				else{
					ServletContext ctx=request.getServletContext();
					int fixedcharge=Integer.parseInt(ctx.getInitParameter("FixedCharge"));
					
					double unitConsumed=curRead-lastRead;
					double netAmount=(unitConsumed * 1.15) + fixedcharge;
					
					request.setAttribute("unitconsumed", unitConsumed);
					request.setAttribute("netAmount", netAmount);
					request.setAttribute("consumer", consumerNo);
					
					BillDTO bill=new BillDTO();
					
					
					try {
						
						bill.setConsumerNo(consumerNo);
						bill.setCurrReading(curRead);
						bill.setNetAmount(netAmount);
						bill.setUnitConsumed(unitConsumed);
						int consNo=services.insertBill(bill);
						if(consNo==0){
							message="Invalid Consumer Number Please Enter Valid Entry";
							request.setAttribute("errorMsg", message);
							response.sendRedirect("errors.html");
						}
						String name=services.getName(consumerNo);
						request.setAttribute("cname", name);
						nextJsp="userInfo.jsp";
						
						HttpSession session=request.getSession(false);
						session.invalidate();
						
						
					} catch (BillExceptions e) {
						response.sendRedirect("errors.html");
						System.out.println(e.getMessage());
					}
					
					
				}
				break;
		case "/search.do":
				nextJsp="search_Consumer.jsp";
			break;
		case "/showBillDetails.do":
			
			int consNo=Integer.parseInt(request.getQueryString().substring(3,9));
			try {
				List<BillDTO> billList=services.showAllConsumers(consNo);
				request.setAttribute("data", billList);
				request.setAttribute("consumNo", consNo);
				nextJsp="show_Bills.jsp";
			} catch (BillExceptions e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
			}
			
			break;
		case "/showConsumer.do":
			
			consumerNo=Integer.parseInt(request.getParameter("consumerNo"));
			System.out.println("wdghfsdh");
			try {
				Consumer consumer=services.showOneConsumer(consumerNo);
				System.out.println(consumer);
				request.setAttribute("consumNo", consumerNo);
				request.setAttribute("name", consumer.getConsumer_name());
				request.setAttribute("addr", consumer.getAddress());
				nextJsp="show_Consumer.jsp";
				
			} catch (BillExceptions e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
			
			break;
		case "/showConsumerList.do":
			try {
				List<Consumer> consumerList=services.showAll();
				request.setAttribute("data", consumerList);
			} catch (BillExceptions e) {
				System.out.println(e.getMessage());
			}
			
				nextJsp="showConsumer_List.jsp";
			
			break;
	
			
						
		}
		dispatch=request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
		
	}

}
