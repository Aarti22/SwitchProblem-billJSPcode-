package com.cg.lab5.service;

import java.util.List;

import com.cg.lab5.dao.EBillDAO;
import com.cg.lab5.dao.EBillDAOImpl;
import com.cg.lab5.dto.BillDTO;
import com.cg.lab5.dto.Consumer;
import com.cg.lab5.exceptions.BillExceptions;

public class EBillServiceImpl implements EBillService {
	EBillDAO dao;
	public EBillServiceImpl() throws BillExceptions {

		dao=new EBillDAOImpl();
	}

	@Override
	public int insertBill(BillDTO bill) throws BillExceptions {
		
		int consumerNo=bill.getConsumerNo();
	
		boolean flag=dao.validateConsumerNo(consumerNo);
		
		if(dao.validateConsumerNo(consumerNo)){
			//System.out.println("sdhgfhsd");
		return dao.insertBill(bill);
		}else{
			return 0;
		}
	}
	
	public String getName(int cno){
		return dao.getConsumerName(cno);
	}

	@Override
	public List<Consumer> showAll() throws BillExceptions {
		
		return dao.showAll();
	}

	@Override
	public Consumer showOneConsumer(int consNo) throws BillExceptions {
		// TODO Auto-generated method stub
		return dao.showOneConsumer(consNo);
	}

	@Override
	public List<BillDTO> showAllConsumers(int consNo) throws BillExceptions {
		// TODO Auto-generated method stub
		return dao.showAllConsumers(consNo);
	}
	

}
