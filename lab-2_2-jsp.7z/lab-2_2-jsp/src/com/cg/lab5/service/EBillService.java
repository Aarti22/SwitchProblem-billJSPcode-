package com.cg.lab5.service;

import java.util.List;

import com.cg.lab5.dto.BillDTO;
import com.cg.lab5.dto.Consumer;
import com.cg.lab5.exceptions.BillExceptions;

public interface EBillService {
	public int insertBill(BillDTO bill) throws BillExceptions;
	public String getName(int cno);
	public List<Consumer> showAll()throws BillExceptions;
	Consumer showOneConsumer(int consNo) throws BillExceptions;
	List<BillDTO> showAllConsumers(int consNo) throws BillExceptions;
}
