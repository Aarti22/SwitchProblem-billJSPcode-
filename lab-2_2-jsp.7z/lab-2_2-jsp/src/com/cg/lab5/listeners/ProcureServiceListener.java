package com.cg.lab5.listeners;


import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import com.cg.lab5.exceptions.BillExceptions;
import com.cg.lab5.service.EBillService;
import com.cg.lab5.service.EBillServiceImpl;

@WebListener
public class ProcureServiceListener implements ServletContextListener {
	private EBillService services;
    private ServletContext ctx=null;
	public void contextInitialized(ServletContextEvent event)  { 
		ctx=event.getServletContext();
		try {
			services=new EBillServiceImpl();
			ctx.setAttribute("services", services);
		} catch (BillExceptions e) {
			ctx.log(e.getMessage());
		}
    }
	
    public void contextDestroyed(ServletContextEvent arg0)  { 
        
    }

	
   
	
}
