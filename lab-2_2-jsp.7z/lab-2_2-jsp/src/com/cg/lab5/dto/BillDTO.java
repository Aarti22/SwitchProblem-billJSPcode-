package com.cg.lab5.dto;

import java.sql.Date;

public class BillDTO {

	private int billNo;
	private int consumerNo;
	private double currReading;
	private double unitConsumed;
	private double netAmount;
	private String billDate;
	public BillDTO() {
		
	}
	public BillDTO(int billNo, int consumerNo, double currReading,
			double unitConsumed, double netAmount, String billDate) {
		super();
		this.billNo = billNo;
		this.consumerNo = consumerNo;
		this.currReading = currReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public int getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}
	public double getCurrReading() {
		return currReading;
	}
	public void setCurrReading(double currReading) {
		this.currReading = currReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	@Override
	public String toString() {
		return "BillDTO [billNo=" + billNo + ", consumerNo=" + consumerNo
				+ ", currReading=" + currReading + ", unitConsumed="
				+ unitConsumed + ", netAmount=" + netAmount + ", billDate="
				+ billDate + "]";
	}
	
}
