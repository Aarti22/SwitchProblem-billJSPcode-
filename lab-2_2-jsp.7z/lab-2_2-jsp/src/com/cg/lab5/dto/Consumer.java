package com.cg.lab5.dto;

public class Consumer {

	private int consumer_no;
	private String consumer_name;
	private String address;
	public Consumer() {
		
	}
	public Consumer(int consumer_no, String consumer_name, String address) {
		super();
		this.consumer_no = consumer_no;
		this.consumer_name = consumer_name;
		this.address = address;
	}
	public int getConsumer_no() {
		return consumer_no;
	}
	public void setConsumer_no(int consumer_no) {
		this.consumer_no = consumer_no;
	}
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Consumer [consumer_no=" + consumer_no + ", consumer_name="
				+ consumer_name + ", address=" + address + "]";
	}
	

}
