package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.dto.Consumers;
import com.cg.appl.dto.User;
import com.cg.appl.exception.ConsumerException;
import com.cg.appl.util.DbUtil;

public class EBillDaoImpl implements IEBillDao{

	private DbUtil util;
	
	public EBillDaoImpl() {
		util=new DbUtil();
	}

	
	public int insertBill(BillDetails bill)throws ConsumerException{
		
		int billid=getBill_num();
		Connection conn=null;
		PreparedStatement pst=null;
		int msg=0;
		String query="INSERT INTO BillDetails VALUES(?,?,?,?,?,sysdate)";
		
		
			
			try {
				conn=DbUtil.obtainConnection();
				pst=conn.prepareStatement(query);
				pst.setInt(1,billid);
				pst.setInt(2,bill.getConsumer_num());
				pst.setInt(3, bill.getCur_reading());
				pst.setInt(4, bill.getUnitConsumed());
				pst.setDouble(5, bill.getNetAmount());
				
				int status=pst.executeUpdate();
				if(status>0){
					msg=billid;
				}
			} catch (SQLException e) {
				
				throw new ConsumerException("Error during preparedstatement");
			}finally{
				try {
					pst.close();
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		
		return msg;
	}

	private int getBill_num() {
		int billid=0;
		Connection conn=null;
		PreparedStatement pst=null;
		
		String query="Select  seq_bill_num.NEXTVAL from DUAL";
		
		
		    try {
				conn=DbUtil.obtainConnection();
				pst=conn.prepareStatement(query);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					billid=rs.getInt(1);
				}
				
			} catch (ConsumerException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			} 
				
		return billid;
	}
	
	
	public String getConsumer_name(int consumer_num)throws ConsumerException{
		
		String consumer_name = null;
		Connection conn=null;
		PreparedStatement pst=null;
	
		String query="Select consumer_name from Consumers where consumer_num=?";

	    try {
			conn=DbUtil.obtainConnection();
			pst=conn.prepareStatement(query);
			
			pst.setInt(1,consumer_num);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				consumer_name=rs.getString(1);
			}
			
		} catch (ConsumerException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		} 
			
		return consumer_name;
		
	}
	
	public List<Consumers> showAllConsumer() throws ConsumerException{
		
		Connection conn=null;
		PreparedStatement pst=null;
		List<Consumers> myList=new ArrayList<Consumers>();
		String query="Select consumer_num,consumer_name,address from Consumers";
		 try {
				conn=DbUtil.obtainConnection();
				pst=conn.prepareStatement(query);
				ResultSet rs=pst.executeQuery();
			
				while(rs.next()){
					Consumers consumer=new Consumers();
					consumer.setConsumer_num(rs.getInt("consumer_num"));
					consumer.setConsumer_name(rs.getString("consumer_name"));
					consumer.setAddress(rs.getString("address"));
					myList.add(consumer);
				}
				
			} catch (ConsumerException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		 return  myList;	
			
		 }
		
	public Consumers showoneconsumer(int consumer_num) throws ConsumerException{
		
		Connection conn=null;
		PreparedStatement pst=null;
		List<Consumers> CusList=new ArrayList<Consumers>();
		
		String query="SELECT consumer_num,consumer_name,address from Consumers where consumer_num=?";
		
			try {
				conn=DbUtil.obtainConnection();
				pst=conn.prepareStatement(query);
				pst.setInt(1, consumer_num);
				ResultSet rs=pst.executeQuery();

				while(rs.next()){
				
					Consumers consumer=new Consumers();
					consumer.setConsumer_num(rs.getInt("consumer_num"));
					consumer.setConsumer_name(rs.getString("consumer_name"));
					consumer.setAddress(rs.getString("address"));
					return consumer;
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
		return null;
		
	}
	
	
	public List<BillDetails> showBillDetails(int consumer_num) throws ConsumerException{
		Connection conn=null;
		PreparedStatement pst=null;
		List<BillDetails> BillList=new ArrayList<BillDetails>();
		
		String query="SELECT bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date from billdetails where consumer_num=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pst=conn.prepareStatement(query);
			pst.setInt(1,consumer_num);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				BillDetails bill=new BillDetails();
				bill.setBill_num(rs.getInt("bill_num"));
				bill.setConsumer_num(rs.getInt("consumer_num"));
				bill.setCur_reading(rs.getInt("cur_reading"));
				bill.setUnitConsumed(rs.getInt("unitConsumed"));
				bill.setNetAmount(rs.getInt("netAmount"));
				bill.setBill_date(rs.getString(6));
				
				BillList.add(bill);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return BillList;
		
	}
	
	
	}

	
	

