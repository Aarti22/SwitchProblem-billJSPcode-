package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.dto.Consumers;
import com.cg.appl.dto.User;
import com.cg.appl.exception.ConsumerException;

public interface IEBillService {

	
	
	int insertBill(BillDetails bill) throws ConsumerException;
	String getConsumer_name(int consumer_num) throws ConsumerException;
	List<Consumers> showAllConsumer() throws ConsumerException;
	List<BillDetails> showBillDetails(int consumer_num) throws ConsumerException;
	public Consumers showoneconsumer(int consumer_num) throws ConsumerException;
}
