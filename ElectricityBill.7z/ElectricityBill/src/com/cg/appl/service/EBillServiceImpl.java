package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dao.EBillDaoImpl;
import com.cg.appl.dao.IEBillDao;
import com.cg.appl.dto.BillDetails;
import com.cg.appl.dto.Consumers;
import com.cg.appl.dto.User;
import com.cg.appl.exception.ConsumerException;



public class EBillServiceImpl implements IEBillService{

	
	 private IEBillDao dao;
	public EBillServiceImpl() {
		dao=new EBillDaoImpl();
	}
	

	@Override
	public int insertBill(BillDetails bill) throws ConsumerException {
		// TODO Auto-generated method stub
		return dao.insertBill(bill) ;
	}
	@Override
	public String getConsumer_name(int consumer_num) throws ConsumerException {
		
		return dao.getConsumer_name(consumer_num);
	}


	@Override
	public List<Consumers> showAllConsumer() throws ConsumerException {
		
		return dao.showAllConsumer();
	}


	@Override
	public Consumers showoneconsumer(int consumer_num) throws ConsumerException {
		// TODO Auto-generated method stub
		return dao.showoneconsumer(consumer_num);
	}


	@Override
	public List<BillDetails> showBillDetails(int consumer_num)
			throws ConsumerException {
		// TODO Auto-generated method stub
		return dao.showBillDetails(consumer_num);
	}
}