package com.cg.appl.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;








import com.cg.appl.dto.BillDetails;
import com.cg.appl.dto.Consumers;
import com.cg.appl.dto.User;
import com.cg.appl.exception.ConsumerException;
import com.cg.appl.service.EBillServiceImpl;
import com.cg.appl.service.IEBillService;


@WebServlet("*.do")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    IEBillService service;
    User user=null;
    public EBillController() {
        super();
        service=new EBillServiceImpl();
       user=new User();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	
	}
	
	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		 
		 String path=request.getServletPath();
		 
		 if(path.equals("/new.do"))
		 {
			 RequestDispatcher dispatch=request.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);
		 }
		 
		 if(path.equals("/authenticate.do"))
		 {
			    String username=request.getParameter("uname");
				String password= request.getParameter("password");
				if (username.equals(user.getUsername())
						&& password.equals(user.getPassword())) {

					HttpSession session = request.getSession(true);
					System.out.println(session.getId());
				
					try {
						response.sendRedirect("selection.jsp");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				} else {
					System.out.println("Invalid Username or Password");
				}
			}
					
		 
		 if(path.equals("/calculate.do")){	
							
					int consumer_num=Integer.parseInt(request.getParameter("consumer_num"));
					int lastreading=Integer.parseInt(request.getParameter("lmr"));
					int cur_reading=Integer.parseInt(request.getParameter("cmr"));
					int fixedcharge=100;
					
					    int unitConsumed = (lastreading - cur_reading) ;
						double netAmount = (unitConsumed * 1.15) + fixedcharge;
						
						BillDetails bill=new BillDetails();
						bill.setConsumer_num(consumer_num);
						bill.setCur_reading(cur_reading);
						bill.setUnitConsumed(unitConsumed);
						bill.setNetAmount(netAmount);
					
					
					    try {
					    	
					    	service.insertBill(bill);
						    String consumer_name=service.getConsumer_name(consumer_num);
						    request.setAttribute("consumer_name",consumer_name);
						    request.setAttribute("unitConsumed",unitConsumed);
						   /* request.setAttribute("netAmount",netAmount);*/
							request.setAttribute("Bill",bill );
							
						} catch (ConsumerException e) {
							
							e.printStackTrace();
						}
					  
					RequestDispatcher dispatch=request.getRequestDispatcher("calculatedbill.jsp");
					dispatch.forward(request, response);
			 }
		
	if(path.equals("/showconsumer.do")){	
		try {
			List<Consumers>myList=service.showAllConsumer();
			request.setAttribute("data",myList);
		} catch (ConsumerException e) {
			
			e.printStackTrace();
		}
		RequestDispatcher dispatch=request.getRequestDispatcher("Show_ConsumerList.jsp");
		dispatch.forward(request, response);
		
	}
				
	   if(path.equals("/search.do"))    {
		   RequestDispatcher dispatch=request.getRequestDispatcher("Search_Consumer.jsp");
			dispatch.forward(request, response);
			
		
	   }
	   if(path.equals("/showoneconsumer.do")) {
		   int consumer_num=Integer.parseInt(request.getParameter("consumer_num"));
		   try {
			Consumers consumer=service.showoneconsumer(consumer_num);
			request.setAttribute("consumer_num", consumer_num);
			request.setAttribute("consumer_name",consumer.getConsumer_name());
			request.setAttribute("address",consumer.getAddress());
			 RequestDispatcher dispatch=request.getRequestDispatcher("Show_Consumer.jsp");
				dispatch.forward(request, response);
			
			
		} catch (ConsumerException e) {
			
			e.printStackTrace();
		}
	   }
	   
	   if(path.equals("/showBillDetails.do")) {
		   
		   int consumer_num=Integer.parseInt(request.getParameter("consumer_num"));
		   try {
			 List<BillDetails> BillList=service.showBillDetails(consumer_num);
			 request.setAttribute("data",BillList);
			 request.setAttribute("consumer_num",consumer_num );
			  RequestDispatcher dispatch=request.getRequestDispatcher("Show_Bills.jsp");
			  dispatch.forward(request, response);
			
			
		} catch (ConsumerException e) {
			
			e.printStackTrace();
		}
		   
	   }
	   }
	}
	


