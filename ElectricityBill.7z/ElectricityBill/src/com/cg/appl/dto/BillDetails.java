package com.cg.appl.dto;

import java.sql.Date;

public class BillDetails {

	public BillDetails() {
	
	}

private int	bill_num;
private int consumer_num;
private int cur_reading;
private int	unitConsumed;
private double 	netAmount;
private String bill_date;

public int getBill_num() {
	return bill_num;
}
public void setBill_num(int bill_num) {
	this.bill_num = bill_num;
}

public int getConsumer_num() {
	return consumer_num;
}
public void setConsumer_num(int consumer_num) {
	this.consumer_num = consumer_num;
}
public int getCur_reading() {
	return cur_reading;
}
public void setCur_reading(int cur_reading) {
	this.cur_reading = cur_reading;
}
public int getUnitConsumed() {
	return unitConsumed;
}
public void setUnitConsumed(int unitConsumed) {
	this.unitConsumed = unitConsumed;
}
public double getNetAmount() {
	return netAmount;
}
public void setNetAmount(double netAmount) {
	this.netAmount = netAmount;
}
public String getBill_date() {
	return bill_date;
}
public void setBill_date(String string) {
	this.bill_date = string;
}
@Override
public String toString() {
	return "BillDetails [bill_num=" + bill_num + ", onsumer_num=" + consumer_num
			+ ", cur_reading=" + cur_reading + ", unitConsumed=" + unitConsumed
			+ ", netAmount=" + netAmount + ", bill_date=" + bill_date + "]";
}


}
