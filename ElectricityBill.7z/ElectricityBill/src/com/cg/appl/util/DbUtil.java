package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exception.ConsumerException;



public class DbUtil {

	public static Connection obtainConnection() throws ConsumerException{
		Connection conn=null;
		InitialContext context;
		try { 
			context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS");
			 conn=source.getConnection();
		} catch (NamingException e) {
		
			throw new ConsumerException("Error during initializations");
		} catch (SQLException e) {
			throw new ConsumerException("Datasource Exception",e);
			
		}
		return conn;
	}
}
